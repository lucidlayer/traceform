// src/background.ts
var BRIDGE_SERVER_URL = "ws://localhost:9901";
var socket = null;
var reconnectInterval = 1e3;
var maxReconnectInterval = 1e4;
console.log("Code-to-UI Mapper: Background service worker started.");
var targetUrl = null;
var checkIntervalId = null;
var lastServerStatus = "idle";
var CHECK_INTERVAL = 5e3;
var panelPorts = /* @__PURE__ */ new Set();
function broadcastToDevtools(message) {
  panelPorts.forEach((port) => {
    try {
      port.postMessage(message);
    } catch (e) {
      console.error("Failed to send message to DevTools panel port:", e);
      panelPorts.delete(port);
    }
  });
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "traceform-panel") {
    panelPorts.add(port);
    console.log(`DevTools panel connected. Total ports: ${panelPorts.size}`);
    appendMessageToPanelLog(`[Info] Panel connection established.`);
    try {
      port.postMessage({ type: "status", status: socket && socket.readyState === WebSocket.OPEN ? "Connected to Bridge Server" : "Disconnected from Bridge Server" });
      port.postMessage({ type: "serverStatus", status: lastServerStatus ?? "idle", url: targetUrl });
    } catch (e) {
      console.error("Error sending initial status to newly connected panel:", e);
    }
    port.onDisconnect.addListener(() => {
      panelPorts.delete(port);
      console.log(`DevTools panel disconnected. Total ports: ${panelPorts.size}`);
    });
  }
});
function appendMessageToPanelLog(logMessage) {
  broadcastToDevtools({ type: "log", message: logMessage });
}
function getEffectiveTargetUrl() {
  return targetUrl || "http://localhost:5173/";
}
async function refreshTargetTab() {
  const effectiveUrl = getEffectiveTargetUrl();
  console.warn(`Attempting refresh for effective URL: ${effectiveUrl}`);
  appendMessageToPanelLog(`Attempting refresh for effective URL: ${effectiveUrl}`);
  try {
    const urlPattern = effectiveUrl.endsWith("/") ? effectiveUrl.slice(0, -1) : effectiveUrl;
    const tabs = await chrome.tabs.query({ url: `${urlPattern}*` });
    if (tabs.length > 0 && tabs[0].id) {
      const tabId = tabs[0].id;
      console.log(`Found target tab ${tabId} matching ${urlPattern}*. Reloading...`);
      appendMessageToPanelLog(`Found target tab ${tabId}. Reloading...`);
      await chrome.tabs.reload(tabId);
      broadcastToDevtools({ type: "status", message: `Reloaded tab ${tabId} (${effectiveUrl})` });
    } else {
      console.warn(`No open tab found matching URL pattern: ${urlPattern}*`);
      broadcastToDevtools({ type: "error", message: `No open tab found for ${effectiveUrl}` });
    }
  } catch (error) {
    console.error("Error refreshing target tab:", error);
    broadcastToDevtools({ type: "error", message: `Error refreshing tab: ${error?.message || error}` });
  }
}
chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  if (msg.type === "getStoredTargetUrl") {
    try {
      const result = await chrome.storage.local.get(["targetUrl"]);
      sendResponse({ url: result.targetUrl || null });
    } catch (error) {
      sendResponse({ url: null, error: error?.toString() });
    }
    return true;
  }
  if (msg.type === "setTargetUrl" && msg.url) {
    try {
      targetUrl = msg.url;
      lastServerStatus = "checking";
      broadcastToDevtools({ type: "serverStatus", status: lastServerStatus, url: targetUrl });
      await chrome.storage.local.set({ targetUrl });
      startServerCheck();
      sendResponse({ success: true });
    } catch (error) {
      sendResponse({ success: false, error: error?.message || error?.toString() });
    }
    return true;
  }
  if (msg.type === "refreshTargetTab") {
    try {
      await refreshTargetTab();
      sendResponse({ success: true });
    } catch (error) {
      sendResponse({ success: false, error: error?.message || error?.toString() });
    }
    return true;
  }
  if (msg.type === "ping") {
    sendResponse({ type: "pong" });
    return true;
  }
  sendResponse({ error: "Unknown message type" });
  return true;
});
async function checkServerStatus() {
  if (!targetUrl) {
    if (lastServerStatus !== "idle") {
      lastServerStatus = "idle";
      broadcastToDevtools({ type: "serverStatus", status: lastServerStatus, url: null });
    }
    return;
  }
  let currentStatus = "down";
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), CHECK_INTERVAL - 500);
    const response = await fetch(targetUrl, { method: "HEAD", signal: controller.signal, mode: "cors", cache: "no-cache" });
    clearTimeout(timeoutId);
    if (response.ok || response.type === "opaque" && response.status === 0) {
      currentStatus = "up";
    } else {
      console.warn(`Server check for ${targetUrl} returned status: ${response.status}`);
      currentStatus = "down";
    }
  } catch (error) {
    if (error.name === "AbortError") {
      console.warn(`Server check for ${targetUrl} timed out.`);
    } else {
      console.warn(`Server check for ${targetUrl} failed:`, error.message || error);
    }
    currentStatus = "down";
  }
  if (currentStatus !== lastServerStatus) {
    console.log(`Server status changed for ${targetUrl}: ${currentStatus}`);
    lastServerStatus = currentStatus;
    broadcastToDevtools({ type: "serverStatus", status: currentStatus, url: targetUrl });
  }
}
function startServerCheck() {
  if (checkIntervalId !== null) {
    clearInterval(checkIntervalId);
    checkIntervalId = null;
    console.log("Stopped previous server check interval.");
  }
  if (targetUrl) {
    console.log(`Starting server check interval for ${targetUrl} every ${CHECK_INTERVAL / 1e3}s`);
    checkServerStatus();
    checkIntervalId = setInterval(checkServerStatus, CHECK_INTERVAL);
  } else {
    if (lastServerStatus !== "idle") {
      console.log("Target URL cleared, stopping server check.");
      lastServerStatus = "idle";
      broadcastToDevtools({ type: "serverStatus", status: "idle", url: null });
    }
  }
}
function connectWebSocket() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    console.log("WebSocket already open or connecting.");
    return;
  }
  console.log(`Attempting to connect to WebSocket: ${BRIDGE_SERVER_URL}`);
  socket = new WebSocket(BRIDGE_SERVER_URL);
  socket.onopen = () => {
    console.log("WebSocket connection established.");
    reconnectInterval = 1e3;
    chrome.action.setTitle({ title: "Traceform (Connected)" });
    broadcastToDevtools({ type: "status", status: "Connected to Bridge Server" });
    appendMessageToPanelLog("[Info] WebSocket connection established.");
  };
  socket.onmessage = (event) => {
    console.log("WebSocket message received:", event.data);
    try {
      const message = JSON.parse(event.data);
      if (!message || !message.type || message.type === "HIGHLIGHT_COMPONENT" && !message.traceformId) {
        console.error("Invalid message format received from WebSocket (expected traceformId for HIGHLIGHT_COMPONENT):", message);
        return;
      }
      const urlToMatch = getEffectiveTargetUrl();
      let urlPattern = urlToMatch;
      if (!urlPattern.endsWith("/")) urlPattern += "/";
      urlPattern += "*";
      chrome.tabs.query({ url: urlPattern }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].id) {
          const targetTabId = tabs[0].id;
          const sendMessageWithRetry = (attempt = 1) => {
            chrome.tabs.sendMessage(targetTabId, message, (response) => {
              if (chrome.runtime.lastError) {
                const errorMessage = chrome.runtime.lastError.message || "Unknown error";
                if (errorMessage.includes("Receiving end does not exist") && attempt < 5) {
                  const delay = 250 * attempt;
                  console.warn(`Attempt ${attempt}: Failed to connect to content script in tab ${targetTabId} ('${errorMessage}'). Retrying in ${delay}ms...`);
                  appendMessageToPanelLog(`[Warning] Attempt ${attempt}: Content script connection failed. Retrying...`);
                  setTimeout(() => sendMessageWithRetry(attempt + 1), delay);
                } else {
                  console.error(`Attempt ${attempt}: Error sending message to tab ${targetTabId}:`, errorMessage);
                  const finalErrorMessage = `Failed to send message to content script in tab ${targetTabId} after ${attempt} attempts. Error: ${errorMessage}. Ensure the target page is loaded and the extension has permissions. Try refreshing the target page.`;
                  broadcastToDevtools({ type: "error", message: finalErrorMessage });
                  appendMessageToPanelLog(`[Error] Failed to send message to content script: ${errorMessage}`);
                }
              } else {
              }
            });
          };
          sendMessageWithRetry();
        } else {
          if (targetUrl) {
            chrome.tabs.query({}, (allTabs) => {
              const openUrls = allTabs.map((tab) => tab.url).filter(Boolean);
              console.error(`Could not find any open tab matching the target URL pattern: ${urlPattern}. Target URL: ${targetUrl}. Open tabs:`, openUrls);
              const errorMsg = `No open tab found matching target URL pattern: ${urlPattern}. Please ensure the page is open.`;
              broadcastToDevtools({ type: "error", message: errorMsg });
              appendMessageToPanelLog(`[Error] ${errorMsg}`);
            });
          }
        }
      });
    } catch (error) {
      console.error("Failed to parse WebSocket message:", error);
      appendMessageToPanelLog(`[Error] Failed to parse WebSocket message: ${error?.message || error}`);
    }
  };
  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };
  socket.onclose = (event) => {
    console.log(
      `WebSocket connection closed. Code: ${event.code}, Reason: ${event.reason}. Attempting reconnect in ${reconnectInterval / 1e3}s.`
    );
    socket = null;
    chrome.action.setTitle({ title: "Traceform (Disconnected)" });
    broadcastToDevtools({ type: "status", status: "Disconnected from Bridge Server" });
    appendMessageToPanelLog(`[Warning] WebSocket closed (Code: ${event.code}). Reconnecting in ${reconnectInterval / 1e3}s.`);
    setTimeout(connectWebSocket, reconnectInterval);
    reconnectInterval = Math.min(reconnectInterval * 2, maxReconnectInterval);
  };
}
connectWebSocket();
chrome.runtime.onStartup.addListener(() => {
  connectWebSocket();
});
chrome.runtime.onInstalled.addListener(() => {
  connectWebSocket();
});
