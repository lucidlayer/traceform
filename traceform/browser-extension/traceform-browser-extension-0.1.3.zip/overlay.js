// src/overlay.ts
var OVERLAY_CONTAINER_ID = "traceform-overlay-container";
var OVERLAY_CLASS = "traceform-highlight-overlay";
function getOverlayContainer() {
  let container = document.getElementById(OVERLAY_CONTAINER_ID);
  if (!container) {
    container = document.createElement("div");
    container.id = OVERLAY_CONTAINER_ID;
    container.style.position = "absolute";
    container.style.top = "0";
    container.style.left = "0";
    container.style.width = "100%";
    container.style.height = `${document.documentElement.scrollHeight}px`;
    container.style.zIndex = "999999";
    container.style.pointerEvents = "none";
    document.body.appendChild(container);
  }
  container.style.height = `${document.documentElement.scrollHeight}px`;
  return container;
}
function removeOverlays() {
  const container = document.getElementById(OVERLAY_CONTAINER_ID);
  if (container) {
    container.innerHTML = "";
  }
}
function highlightElements(traceformId) {
  removeOverlays();
  const container = getOverlayContainer();
  const selector = `[data-traceform-id="${traceformId}"]`;
  console.log(`[Traceform Overlay] Attempting querySelectorAll with selector: ${selector}`);
  const elements = document.querySelectorAll(selector);
  if (elements.length === 0) {
    console.log(`No elements found for traceformId: ${traceformId}`);
    return;
  }
  console.log(`Highlighting ${elements.length} elements for: ${traceformId}`);
  elements.forEach((element) => {
    const rect = element.getBoundingClientRect();
    const overlay = document.createElement("div");
    overlay.className = OVERLAY_CLASS;
    overlay.style.position = "absolute";
    overlay.style.top = `${rect.top + window.scrollY}px`;
    overlay.style.left = `${rect.left + window.scrollX}px`;
    overlay.style.width = `${rect.width}px`;
    overlay.style.height = `${rect.height}px`;
    container.appendChild(overlay);
  });
}
export {
  highlightElements,
  removeOverlays
};
