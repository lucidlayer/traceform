// src/background.ts
var BRIDGE_SERVER_URL = "ws://localhost:9901";
var socket = null;
var reconnectInterval = 5e3;
var maxReconnectInterval = 6e4;
console.log("Code-to-UI Mapper: Background service worker started.");
function connectWebSocket() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    console.log("WebSocket already open or connecting.");
    return;
  }
  console.log(`Attempting to connect to WebSocket: ${BRIDGE_SERVER_URL}`);
  socket = new WebSocket(BRIDGE_SERVER_URL);
  socket.onopen = () => {
    console.log("WebSocket connection established.");
    reconnectInterval = 5e3;
    chrome.action.setTitle({ title: "Code-to-UI Mapper (Connected)" });
  };
  socket.onmessage = (event) => {
    console.log("WebSocket message received:", event.data);
    try {
      const message = JSON.parse(event.data);
      if (!message || !message.type || !message.componentName) {
        console.error("Invalid message format received from WebSocket:", message);
        return;
      }
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].id) {
          const activeTabId = tabs[0].id;
          console.log(`Relaying message to tab ID: ${activeTabId}`, message);
          const sendMessageWithRetry = (tabId, msg, attempt = 1) => {
            const maxAttempts = 5;
            const delay = 100 * Math.pow(2, attempt - 1);
            chrome.tabs.sendMessage(tabId, msg, (response) => {
              if (chrome.runtime.lastError) {
                const errorMessage = chrome.runtime.lastError.message ?? "Unknown error";
                if (!errorMessage.includes("the message channel closed before a response was received")) {
                  console.error(
                    `Error sending message to content script (tab ${tabId}, attempt ${attempt}):`,
                    errorMessage
                  );
                }
              } else {
                if (response) {
                  console.log(`Content script (tab ${tabId}) unexpectedly responded:`, response);
                }
              }
            });
          };
          sendMessageWithRetry(activeTabId, message);
        } else {
          console.error("Could not find active tab to send message to.");
        }
      });
    } catch (error) {
      console.error("Failed to parse WebSocket message:", error);
    }
  };
  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };
  socket.onclose = (event) => {
    console.log(
      `WebSocket connection closed. Code: ${event.code}, Reason: ${event.reason}. Attempting reconnect in ${reconnectInterval / 1e3}s.`
    );
    socket = null;
    chrome.action.setTitle({ title: "Code-to-UI Mapper (Disconnected)" });
    setTimeout(connectWebSocket, reconnectInterval);
    reconnectInterval = Math.min(reconnectInterval * 2, maxReconnectInterval);
  };
}
connectWebSocket();
chrome.runtime.onStartup.addListener(() => {
  console.log("Extension startup: attempting WebSocket connection.");
  connectWebSocket();
});
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/updated: attempting WebSocket connection.");
  connectWebSocket();
});
